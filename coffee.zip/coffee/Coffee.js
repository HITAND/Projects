const body1 = document.querySelector(".body1");
const menuBurger = document.querySelector(".menu__burger");
const menuDrop = document.querySelector(".drop__menu");
const ulMenu = document.querySelector(".ul__menu");
const burgerActive = document.querySelector(".burger__active");
const burger = document.querySelector(".burger");
const closeBurger = document.querySelector(".close__burger");
const close = document.querySelector(".close");
const header = document.querySelector(".header");
const dropActive = document.querySelector(".drop__active");
const inputSearch = document.querySelector(".input__search");
const logoSearch = document.querySelector(".logo__search");
const closeButton = document.querySelector(".close__Button");
const findStore = document.querySelector(".Find__Store");
const headerFSJ = document.querySelector(".header__FSJ");
const signIn = document.querySelector(".header__FSJ > li:nth-child(1)");
const boxContent = document.querySelector(".box__content");
const boxContent2 = document.querySelector(".box__content2");
const boxContent3 = document.querySelector(".box__content3");
const boxContent4 = document.querySelector(".box__content4");
const boxContent5 = document.querySelector(".box__content5");
const boxContent6 = document.querySelector(".box__content6");
const li1 = document.querySelector(".li_1");
const li2 = document.querySelector(".li_2");
const li3 = document.querySelector(".li_3");
const li4 = document.querySelector(".li_4");
const li5 = document.querySelector(".li_5");
const li6 = document.querySelector(".li_6");
const li7 = document.querySelector(".li_7");
const li1_1 = document.querySelector(".li1_1");
const li2_2 = document.querySelector(".li2_2");
const li3_3 = document.querySelector(".li3_3");
const li4_4 = document.querySelector(".li4_4");
const li5_5 = document.querySelector(".li5_5");
const li6_6 = document.querySelector(".li6_6");
const li7_7 = document.querySelector(".li7_7");
const scrollBottom = document.querySelector(".scroll__bottom");
const buttonSlider1 = document.querySelector(".button__slider1");
const buttonSlider2 = document.querySelector(".button__slider2");
const slider1 = document.querySelector(".slider1");

signIn.onclick = () => {
	body1.style.display = "flex";
}

body1.onclick = () => {
	body1.style.display = "none";
}


menuBurger.onclick = () => {
	menuDrop.classList.toggle("drop__active");
	burgerActive.classList.toggle("burger");
	closeBurger.classList.toggle("close");
}

inputSearch.onclick = () => {
	inputSearch.classList.toggle("Search__width")
	findStore.classList.toggle("Store__none")
	headerFSJ.classList.toggle("FSJ__none");
	closeButton.classList.toggle("Button__add")
}

window.onscroll = () => {

	if (window.scrollY > 150) {
		scrollBottom.classList.add("active__scroll");
	} else {
		scrollBottom.classList.remove("active__scroll");
	 scrollBottom.style.transition = '0.2s';
  }

scrollBottom.onclick = () => {
	window.scrollTo({
		top: 0,
		behavior: "smooth"
		});

}
}

li1.onclick = () => {
	window.scrollTo({
		top: 0,
		behavior: "smooth"
	})
}

li1_1.onclick = () => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		})
}

li2.onclick = () => {
 boxContent.scrollIntoView({block: "center", behavior: "smooth"});
}

li2_2.onclick = () => {
	boxContent.scrollIntoView({block: "center", behavior: "smooth"});
}
	

li3.onclick = () => {
	boxContent3.scrollIntoView({block: "end", behavior: "smooth"});
}

li3_3.onclick = () => {
	boxContent3.scrollIntoView({block: "end", behavior: "smooth"});
}

li4.onclick = () => {
	boxContent2.scrollIntoView({block: "center", behavior: "smooth"});
}

li4_4.onclick = () => {
	boxContent2.scrollIntoView({block: "center", behavior: "smooth"});
}

li5.onclick = () => {
	boxContent4.scrollIntoView({block: "start", behavior: "smooth"});

}

li5_5.onclick = () => {
	boxContent4.scrollIntoView({block: "start", behavior: "smooth"});
}

li6.onclick = () => {
	boxContent5.scrollIntoView({block: "start", behavior: "smooth"});
}

li6_6.onclick = () => {
	boxContent5.scrollIntoView({block: "start", behavior: "smooth"});
}

li7.onclick = () => {
	boxContent6.scrollIntoView({block: "end", behavior: "smooth"});
}

li7_7.onclick = () => {
	boxContent6.scrollIntoView({block: "end", behavior: "smooth"});
}

buttonSlider1.onclick = () => {
	sliderVariable1 = slider1.style.left = '-200px';
}

buttonSlider2.onclick = () => {
	sliderVariable2 = slider1.style.left = '200px';

}